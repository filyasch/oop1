public class MainClass {
    public static void main(String[] args) {
        HashMultiSet<String> multiSet = new HashMultiSet<>();
        multiSet.add("apple");
        multiSet.add("banana");
        multiSet.add("apple");
        multiSet.add("orange");

        System.out.println("Multiset: " + multiSet);
        System.out.println("Count of apples: " + multiSet.occurrences("apple"));
        System.out.println("Number of distinct elements: " + multiSet.size());

        multiSet.remove("apple");
        System.out.println("Multiset after removing one apple: " + multiSet);
    }
}
