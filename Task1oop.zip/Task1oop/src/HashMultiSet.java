import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashMultiSet<T> implements MultiSet<T> {

    Map<T, Integer> map = new HashMap<>();

    public HashMultiSet() {
        // empty constructor
    }

    public HashMultiSet(MultiSet<T> prototype) {
        for (T object : prototype.keySet()) {
            map.put(object, prototype.occurrences(object));
        }
    }

    @Override
    public boolean contains(T key) {
        return occurrences(key) > 0;
    }

    @Override
    public int occurrences(T key) {
        if (!map.containsKey(key)) {
            return 0;
        }
        return map.get(key);
    }

    @Override
    public void add(T key) {
        if (!map.containsKey(key)) {
            map.put(key, 1);
        } else {
            map.put(key, map.get(key) + 1);
        }
    }

    @Override
    public void add(T key, int occurrences) {
        if (!map.containsKey(key)) {
            map.put(key, occurrences);
        } else {
            map.put(key, map.get(key) + occurrences);
        }
    }

    @Override
    public void addAll(Collection<T> keys) {
        for (T key : keys) {
            add(key);
        }
    }

    @Override
    public void addAll(Collection<T> keys, int occurrences) {
        for (T key : keys) {
            add(key, occurrences);
        }
    }

    @Override
    public void remove(T key) {
        if (!map.containsKey(key)) {
            return;
        }
        int count = map.get(key) - 1;
        if (count == 0) {
            map.remove(key);
        } else {
            map.put(key, count);
        }
    }

    @Override
    public void removeAll(Collection<? extends T> c) {
        for (T key : c) {
            remove(key);
        }
    }

    @Override
    public void removeOccurrences(T key) {
        if (!map.containsKey(key)) {
            return;
        }
        map.remove(key);
    }

    @Override
    public void removeAllOccurrences(Collection<? extends T> c) {
        for (T key : c) {
            removeOccurrences(key);
        }
    }

    @Override
    public void removeN(T key, int n) {
        if (!map.containsKey(key)) {
            return;
        }
        int count = map.get(key) - n;
        if (count <= 0) {
            map.remove(key);
        } else {
            map.put(key, count);
        }
    }

    @Override
    public void removeAllN(Collection<? extends T> c, int n) {
        for (T key : c) {
            removeN(key, n);
        }
    }

    @Override
    public Set<T> keySet() {
        return map.keySet();
    }

    @Override
    public Iterator<T> iterator() {
        return new HashMultiSetIterator<>(this);
    }

    @Override
    public int size() {
        return map.size();
    }

    private class HashMultiSetIterator<K> implements Iterator<K> {

        private HashMultiSet<K> hms;
        private int leftForThis = 0;
        private Set<K> keys;
        private K current;

        public HashMultiSetIterator(HashMultiSet<K> hms) {
            this.hms = hms;
            keys = new HashSet<>();
            for (K key : hms.keySet()) {
                keys.add(key);
            }
        }

        @Override
        public boolean hasNext() {
            if (leftForThis == 0) {
                return !keys.isEmpty();
            }
            return true;
        }

        @Override
        public K next() {
            if (leftForThis == 0) {
                current = keys.iterator().next();
                leftForThis = hms.occurrences(current);
                keys.remove(current);
            }
            leftForThis -= 1;
            return current;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException(
                    "HashMultiSet iterators don't provide removal method");
        }
    }
}
