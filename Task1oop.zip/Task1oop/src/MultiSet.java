import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

public interface MultiSet<T> {
    boolean contains(T key);

    int occurrences(T key);

    void add(T key);

    void add(T key, int occurrences);

    void addAll(Collection<T> keys);

    void addAll(Collection<T> keys, int occurrences);

    void remove(T key);

    void removeAll(Collection<? extends T> keys);

    void removeOccurrences(T key);

    void removeAllOccurrences(Collection<? extends T> keys);

    void removeN(T key, int n);

    void removeAllN(Collection<? extends T> keys, int n);

    Set<T> keySet();

    Iterator<T> iterator();

    int size();
}
